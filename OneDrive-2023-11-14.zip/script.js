<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Your Webpage Title</title>
  <style>
    /* Add your styles here */
    [data-navbar] {
      /* Add your navbar styles here */
      display: none;
    }

    [data-navbar].active {
      display: block;
    }

    [data-header].active {
      /* Add your active header styles here */
      background-color: lightblue;
    }
  </style>
</head>
<body>

  <!-- Your HTML content here -->

  <button data-nav-open-btn>Open Navbar</button>
  <button data-nav-close-btn>Close Navbar</button>

  <nav data-navbar>
    <ul>
      <li><a href="#" data-nav-link>Link 1</a></li>
      <li><a href="#" data-nav-link>Link 2</a></li>
      <li><a href="#" data-nav-link>Link 3</a></li>
    </ul>
  </nav>

  <header data-header>
    <!-- Your header content here -->
    Header Content
  </header>

  <script>
    'use strict';

    /**
     * Navbar toggle
     */

    const navOpenBtn = document.querySelector("[data-nav-open-btn]");
    const navbar = document.querySelector("[data-navbar]");
    const navCloseBtn = document.querySelector("[data-nav-close-btn]");

    const toggleNavbar = function () {
      navbar.classList.toggle("active");
    };

    navOpenBtn.addEventListener("click", toggleNavbar);
    navCloseBtn.addEventListener("click", toggleNavbar);

    /**
     * Toggle navbar when clicking any navbar link
     */

    const navbarLinks = document.querySelectorAll("[data-nav-link]");

    for (let i = 0; i < navbarLinks.length; i++) {
      navbarLinks[i].addEventListener("click", function () {
        navbar.classList.remove("active");
      });
    }

    /**
     * Header active when window scrolled down
     */

    const header = document.querySelector("[data-header]");

    window.addEventListener("scroll", function () {
      window.scrollY >= 50 ? header.classList.add("active") : header.classList.remove("active");
    });
  </script>
</body>
</html>
